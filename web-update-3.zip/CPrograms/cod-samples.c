
		
		
		
======================================================================================================================================

C Program to Display Factors of a Number.

Example to find all factors of an integer (entered by the user) using for loop and if statement.

#include &lt;stdio.h&gt;
int main()
{
    int number, i;

    printf(&quot;Enter a positive integer: &quot;);
    scanf(&quot;%d&quot;,&amp;number);

    printf(&quot;Factors of %d are: &quot;, number);
    for(i=1; i &lt;= number; ++i)
    {
        if (number%i == 0)
        {
            printf(&quot;%d &quot;,i);
        }
    }

    return 0;
}



Output:

Enter a positive integer: 60
Factors of 60 are: 1 2 3 4 5 6 10 12 15 20 30 60

====================================================================================================================================================



























































































































